### 6 强化学习基本算法

* snake.py：蛇棋环境

* policy_iter.py：策略迭代法实现

* value_iter.py：价值迭代法实现

* generalized.py：泛化迭代法实现

  ​